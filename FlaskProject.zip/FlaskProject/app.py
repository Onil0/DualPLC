from flask import Flask, render_template, request, redirect, url_for
from pymodbus.client import ModbusTcpClient
import threading
import time

app = Flask(__name__)

OPENPLC_IP = '127.0.0.1'
SIEMENS_IP = '192.168.0.3'
PORT = 502

OPENPLC_M1 = 0
OPENPLC_M2 = 1
SIEMENS_M1 = 8257
SIEMENS_M2 = 8258

ambiente = '1'
motore2_durata = 8
conteggio_cicli = 0
motore_attivo = False

def spegni_motore2_dopo_delay(client, m2, delay):
    time.sleep(delay)
    client.write_coil(m2, False)
    print("Motore2 spento automaticamente dopo", delay, "secondi")

@app.route('/', methods=['GET', 'POST'])
def index():
    global ambiente, motore2_durata, conteggio_cicli, motore_attivo

    stato_m1 = False
    stato_m2 = False

    if request.method == 'POST':
        ambiente = request.form.get('ambiente')
        durata_input = request.form.get('durata')
        motore2_durata = int(durata_input) if durata_input.isdigit() else 8
        action = request.form.get('azione')

        if ambiente == "1":
            ip = OPENPLC_IP
            m1 = OPENPLC_M1
            m2 = OPENPLC_M2
        else:
            ip = SIEMENS_IP
            m1 = SIEMENS_M1
            m2 = SIEMENS_M2

        client = ModbusTcpClient(ip, port=PORT)
        client.connect()

        if action == 'start':
            client.write_coil(m1, True)
            client.write_coil(m2, True)
            motore_attivo = True

            if ambiente == "1":
                threading.Thread(target=spegni_motore2_dopo_delay, args=(client, m2, motore2_durata), daemon=True).start()

        elif action == 'stop':
            client.write_coil(m1, False)
            client.write_coil(m2, False)

            if motore_attivo:
                conteggio_cicli += 1
                motore_attivo = False

        client.close()
        return redirect(url_for('index'))

    # === LETTURA STATO USCITE ===
    if ambiente == "1":
        ip = OPENPLC_IP
        m1 = OPENPLC_M1
        m2 = OPENPLC_M2
    else:
        ip = SIEMENS_IP
        m1 = SIEMENS_M1
        m2 = SIEMENS_M2

    client = ModbusTcpClient(ip, port=PORT)
    client.connect()
    res_m1 = client.read_coils(m1, count=1)
    res_m2 = client.read_coils(m2, count=1)

    stato_m1 = res_m1.bits[0] if res_m1 and hasattr(res_m1, 'bits') else False
    stato_m2 = res_m2.bits[0] if res_m2 and hasattr(res_m2, 'bits') else False

    client.close()

    return render_template('index.html',
                           ambiente=ambiente,
                           durata=motore2_durata,
                           cicli=conteggio_cicli,
                           stato_m1=stato_m1,
                           stato_m2=stato_m2)

if __name__ == '__main__':
    app.run(debug=True)
